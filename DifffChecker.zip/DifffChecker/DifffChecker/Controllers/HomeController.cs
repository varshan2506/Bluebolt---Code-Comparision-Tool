using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Text;
using System.Web;
using System.Collections.Generic;
using System.Linq;

namespace DifffChecker.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Compare(IFormFile file1, IFormFile file2)
        {
            if (file1 != null && file2 != null)
            {
                string code1 = ReadFile(file1);
                string code2 = ReadFile(file2);

                // Store file names in ViewData
                ViewData["FileName1"] = Path.GetFileName(file1.FileName);
                ViewData["FileName2"] = Path.GetFileName(file2.FileName);

                // Remove file paths and comment tags from code2 for the updated code file
                string updatedCodeFileContent = RemoveFilePathLines(RemoveCommentTags(code2));

                var differences = GetDifferences(code1, code2);

                ViewData["Code1"] = differences.Item1;  // Highlighted code1
                ViewData["Code2"] = differences.Item2;  // Highlighted code2
                ViewData["UpdatedCodeFile"] = HttpUtility.HtmlEncode(updatedCodeFileContent); // Updated code without file paths and comments
                ViewData["Differences"] = differences.Item3;
                ViewData["TotalChanges"] = differences.Item6;

                ViewData["TotalLines1"] = code1.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None).Length;
                ViewData["TotalLines2"] = code2.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None).Length;
                ViewData["TotalWords1"] = code1.Split(new[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
                ViewData["TotalWords2"] = code2.Split(new[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;

                ViewData["LinesRemoved"] = differences.Item4;  // Number of lines removed
                ViewData["LinesAdded"] = differences.Item5;    // Number of lines added
            }

            return View("Index");
        }

        [HttpPost]
        public IActionResult Clear()
        {
            // Clear the file name view data and other related data
            ViewData["FileName1"] = null;
            ViewData["FileName2"] = null;
            ViewData["Code1"] = null;
            ViewData["Code2"] = null;
            ViewData["UpdatedCodeFile"] = null;
            ViewData["Differences"] = null;
            ViewData["TotalChanges"] = 0; // Reset if necessary
            ViewData["TotalLines1"] = 0;
            ViewData["TotalLines2"] = 0;
            ViewData["TotalWords1"] = 0;
            ViewData["TotalWords2"] = 0;
            ViewData["LinesRemoved"] = 0;
            ViewData["LinesAdded"] = 0;
            


            return View("Index");
        }

        private string ReadFile(IFormFile file)
        {
            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                return reader.ReadToEnd();
            }
        }

        private (string, string, string, int, int, int) GetDifferences(string code1, string code2)
        {
            string[] code1Lines = code1.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            string[] code2Lines = code2.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);

            int[,] dp = new int[code1Lines.Length + 1, code2Lines.Length + 1];

            // Build the DP table
            for (int i = 1; i <= code1Lines.Length; i++)
            {
                for (int j = 1; j <= code2Lines.Length; j++)
                {
                    if (Normalize(code1Lines[i - 1]) == Normalize(code2Lines[j - 1]))
                    {
                        dp[i, j] = dp[i - 1, j - 1] + 1;
                    }
                    else
                    {
                        dp[i, j] = Math.Max(dp[i - 1, j], dp[i, j - 1]);
                    }
                }
            }

            var highlightedCode1 = new StringBuilder();
            var highlightedCode2 = new StringBuilder();
            var diff = new StringBuilder();

            int x = code1Lines.Length, y = code2Lines.Length;
            int linesRemoved = 0, linesAdded = 0;

            // Backtrack to find differences
            while (x > 0 && y > 0)
            {
                if (Normalize(code1Lines[x - 1]) == Normalize(code2Lines[y - 1]))
                {
                    highlightedCode1.Append($"<span class='line-number'>{x}</span> {HttpUtility.HtmlEncode(code1Lines[x - 1])}<br>");
                    highlightedCode2.Append($"<span class='line-number'>{y}</span> {HttpUtility.HtmlEncode(code2Lines[y - 1])}<br>");
                    x--;
                    y--;
                }
                else if (dp[x - 1, y] >= dp[x, y - 1])
                {
                    highlightedCode1.Append($"<span class='line-number'>{x}</span> <span style='background-color: #e74c3c; color: white;'>{HttpUtility.HtmlEncode(code1Lines[x - 1])}</span><br>");
                    highlightedCode2.Append($"<span class='line-number'></span><br>");  // Placeholder in code2
                    diff.AppendLine($"Line {x}: \"{HttpUtility.HtmlEncode(code1Lines[x - 1])}\" is removed.");
                    linesRemoved++;
                    x--;
                }
                else
                {
                    highlightedCode1.Append($"<span class='line-number'></span><br>");  // Placeholder in code1
                    highlightedCode2.Append($"<span class='line-number'>{y}</span> <span style='background-color: #2ecc71; color: white;'>{HttpUtility.HtmlEncode(code2Lines[y - 1])}</span><br>");
                    diff.AppendLine($"Line {y}: \"{HttpUtility.HtmlEncode(code2Lines[y - 1])}\" is added.");
                    linesAdded++;
                    y--;
                }
            }

            // Handle remaining lines in code1
            while (x > 0)
            {
                highlightedCode1.Append($"<span class='line-number'>{x}</span> <span style='background-color: #e74c3c; color: white;'>{HttpUtility.HtmlEncode(code1Lines[x - 1])}</span><br>");
                highlightedCode2.Append($"<span class='line-number'></span><br>");
                diff.AppendLine($"Line {x}: \"{HttpUtility.HtmlEncode(code1Lines[x - 1])}\" is removed.");
                linesRemoved++;
                x--;
            }

            // Handle remaining lines in code2
            while (y > 0)
            {
                highlightedCode1.Append($"<span class='line-number'></span><br>");  // Placeholder in code1
                highlightedCode2.Append($"<span class='line-number'>{y}</span> <span style='background-color: #2ecc71; color: white;'>{HttpUtility.HtmlEncode(code2Lines[y - 1])}</span><br>");
                diff.AppendLine($"Line {y}: \"{HttpUtility.HtmlEncode(code2Lines[y - 1])}\" is added.");
                linesAdded++;
                y--;
            }

            // Reverse the highlighted outputs for correct order
            return (ReverseLines(highlightedCode1.ToString()), ReverseLines(highlightedCode2.ToString()), diff.ToString(), linesRemoved, linesAdded, 0); // Count words as needed
        }

        private string Normalize(string line)
        {
            return line.Trim();  // Normalize for comparison
        }

        private string ReverseLines(string input)
        {
            var lines = input.Split(new[] { "<br>", "<br />", "\n" }, StringSplitOptions.None);
            Array.Reverse(lines);
            return string.Join("<br>", lines);
        }

        private string RemoveFilePathLines(string code)
        {
            var lines = code.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var filteredLines = lines.Where(line => !IsFilePath(line)).ToList();
            return string.Join("\n", filteredLines);
        }

        private string RemoveCommentTags(string code)
        {
            // Remove comment tags like <!-- -->
            return System.Text.RegularExpressions.Regex.Replace(code, @"<!--.*?-->", string.Empty, System.Text.RegularExpressions.RegexOptions.Singleline);
        }

        private bool IsFilePath(string line)
        {
            // Simple heuristic to identify file paths; adjust as necessary
            return line.StartsWith("/") || line.Contains(":\\") || line.Contains("\\");
        }
    }
}